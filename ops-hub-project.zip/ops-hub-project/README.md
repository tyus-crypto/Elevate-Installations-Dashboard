# Ops Hub

An internal dashboard that consolidates your team's links (HubSpot, Gmail,
ClickUp, Claude tools) into one place, with a no-login client status view and
a lightly-gated admin section.

## What's in this folder

| File | Purpose |
|---|---|
| `hub.html` | The dashboard itself — Team Hub, Client View, and Admin tabs. Open it directly in a browser to preview. |
| `sprint-plan.html` | An interactive, checkbox-driven sprint plan for rolling this out in 8 sessions. Progress saves in your browser. |
| `middleware.js` | Optional Vercel Edge Middleware that adds a free basic-auth gate on `/admin`, for teams not paying for Vercel's built-in Password Protection. |
| `README.md` | This file. |

## Before you go live

`hub.html` currently has placeholder content in a few spots:

- The quote calculator tile is disabled — send Claude the real
  `quote_calculator.html` file so it can be merged into this project and
  linked properly (it currently only works as a local file on one computer).
- The Client View tab has three sample project rows — replace the link with
  a real ClickUp **Public View** link once you've set one up per client
  (Session 4 in the sprint plan).
- The Admin tab's passcode defaults to `admin` — change the `PASSCODE`
  variable inside `hub.html`'s `<script>` section before sharing this with
  anyone.

None of the admin gating in `hub.html` (the passcode) or `middleware.js`
(basic auth) is meant for genuinely sensitive data — payroll, contracts, and
similar belong in HubSpot's or ClickUp's own permission systems, not in this
dashboard.

## Deploying to Vercel

One-time setup:

```bash
npm install -g vercel
vercel login
vercel
```

From then on, after making changes:

```bash
git add .
git commit -m "describe what changed"
vercel --prod
```

If you want the free basic-auth gate on `/admin`, keep `middleware.js` in
the project root — Vercel picks it up automatically. Update the
`yourusername:yourpassword` placeholder inside it first.

If you'd rather pay for Vercel's native password protection instead of using
`middleware.js`: Project → Settings → Deployment Protection → Password
Protection (Pro add-on or Enterprise).

## Working through the rollout

Open `sprint-plan.html` in a browser and go session by session. It's a
regular HTML file — you can open it locally, or deploy it alongside
`hub.html` if you'd like a shareable version for anyone else involved in
setup.
