// Basic auth gate for the /admin section.
// Only runs on the free tier if you're NOT paying for Vercel's built-in
// Password Protection (Settings > Deployment Protection).
//
// IMPORTANT: change the username/password below before deploying.

export const config = {
  matcher: '/admin',
};

export default function middleware(request) {
  const auth = request.headers.get('authorization');
  const validAuth = 'Basic ' + btoa('yourusername:yourpassword');

  if (auth !== validAuth) {
    return new Response('Auth required', {
      status: 401,
      headers: { 'WWW-Authenticate': 'Basic realm="Admin"' },
    });
  }
}
